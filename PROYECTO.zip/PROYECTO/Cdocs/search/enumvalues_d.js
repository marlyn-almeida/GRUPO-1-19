var searchData=
[
  ['red_0',['RED',['../graphics_8h.html#aedd64c3f92da850b93776c65fd1cced3af80f9a890089d211842d59625e561f88',1,'graphics.h']]],
  ['right_5ftext_1',['RIGHT_TEXT',['../graphics_8h.html#a92d4e48b203a72f10f2471d0906d7f43a182b84b35f49e4e57b7d4d5b9e894cec',1,'graphics.h']]]
];
