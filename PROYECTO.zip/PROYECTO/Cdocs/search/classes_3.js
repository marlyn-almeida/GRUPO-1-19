var searchData=
[
  ['generar_0',['Generar',['../class_generar.html',1,'']]]
];
