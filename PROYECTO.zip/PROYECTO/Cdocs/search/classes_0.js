var searchData=
[
  ['arccoordstype_0',['arccoordstype',['../structarccoordstype.html',1,'']]]
];
