var searchData=
[
  ['_5fdefaultxpelspermeter_5f_0',['_DefaultXPelsPerMeter_',['../_easy_b_m_p_8h.html#ae686f1339cc6f498a36a965260e0fc21',1,'EasyBMP.h']]],
  ['_5fdefaultypelspermeter_5f_1',['_DefaultYPelsPerMeter_',['../_easy_b_m_p_8h.html#a85b66c0d45760f7b34101418b148a8c8',1,'EasyBMP.h']]],
  ['_5feasybmp_5fdatastructures_5fh_5f_2',['_EasyBMP_DataStructures_h_',['../_easy_b_m_p___data_structures_8h.html#a671d026e9269ec154aa2ed113bab11d6',1,'EasyBMP_DataStructures.h']]],
  ['_5feasybmp_5fdefined_5fwingdi_3',['_EasyBMP_Defined_WINGDI',['../_easy_b_m_p___data_structures_8h.html#ab1979249965f9169f392833da0307d40',1,'EasyBMP_DataStructures.h']]],
  ['_5feasybmp_5fversion_5f_4',['_EasyBMP_Version_',['../_easy_b_m_p_8h.html#a603da21fb9911d4e9ed84ffe16d61297',1,'EasyBMP.h']]],
  ['_5feasybmp_5fversion_5finteger_5f_5',['_EasyBMP_Version_Integer_',['../_easy_b_m_p_8h.html#a9c97040f27886f2282883c58a1882eef',1,'EasyBMP.h']]],
  ['_5feasybmp_5fversion_5fstring_5f_6',['_EasyBMP_Version_String_',['../_easy_b_m_p_8h.html#a4d893b3d4354ace9917ea74dc0822775',1,'EasyBMP.h']]],
  ['_5feasybmpwarnings_5f_7',['_EasyBMPwarnings_',['../_easy_b_m_p_8h.html#ab66dc9dc9a243f9ea4a7dca1419d81e2',1,'EasyBMP.h']]]
];
