var searchData=
[
  ['intentos_0',['INTENTOS',['../_proyecto_8cpp.html#adfb2831c5047720d2da11aefefe6cde2',1,'Proyecto.cpp']]],
  ['is_5fbgi_5fcolor_1',['IS_BGI_COLOR',['../graphics_8h.html#a94cfe89681502ca2dcbcf1f33c5ba25c',1,'graphics.h']]],
  ['is_5frgb_5fcolor_2',['IS_RGB_COLOR',['../graphics_8h.html#a56474f4357170fc8c50213876e7c9a5c',1,'graphics.h']]]
];
