var searchData=
[
  ['backspace_0',['BACKSPACE',['../_proyecto_8cpp.html#a629568514359445d2fbda71d70eeb1ce',1,'Proyecto.cpp']]],
  ['blue_5fvalue_1',['BLUE_VALUE',['../graphics_8h.html#a70a057a166be2763fd9190cd2028b5e2',1,'graphics.h']]]
];
