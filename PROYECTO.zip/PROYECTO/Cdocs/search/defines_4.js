var searchData=
[
  ['defaultxpelspermeter_0',['DefaultXPelsPerMeter',['../_easy_b_m_p_8h.html#af7eb31fa97b9d2c823bb12255dfb725a',1,'EasyBMP.h']]],
  ['defaultypelspermeter_1',['DefaultYPelsPerMeter',['../_easy_b_m_p_8h.html#ae07aa0909b1dce7af7b038e84beef89d',1,'EasyBMP.h']]],
  ['down_2',['DOWN',['../_options_8h.html#a4193cd1c8c2e6ebd0e056fa2364a663f',1,'Options.h']]]
];
