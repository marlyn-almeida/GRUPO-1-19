var searchData=
[
  ['vertical_0',['vertical',['../graphics_8h.html#a33dff256605d1f044e3d4fd788eaf671',1,'graphics.h']]]
];
