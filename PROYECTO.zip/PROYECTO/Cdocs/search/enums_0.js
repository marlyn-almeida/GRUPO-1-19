var searchData=
[
  ['colors_0',['colors',['../graphics_8h.html#aedd64c3f92da850b93776c65fd1cced3',1,'graphics.h']]]
];
