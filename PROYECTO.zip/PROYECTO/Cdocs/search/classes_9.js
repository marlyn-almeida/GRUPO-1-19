var searchData=
[
  ['palettetype_0',['palettetype',['../structpalettetype.html',1,'']]],
  ['pdf_1',['PDF',['../class_p_d_f.html',1,'']]]
];
