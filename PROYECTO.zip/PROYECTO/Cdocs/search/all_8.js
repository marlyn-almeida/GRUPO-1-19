var searchData=
[
  ['h_0',['h',['../pruebafinal_8cpp.html#a16611451551e3d15916bae723c3f59f7',1,'pruebafinal.cpp']]],
  ['hatch_5ffill_1',['HATCH_FILL',['../graphics_8h.html#aec2d632a0960980c5cd973978b12953ba527e5ec44c96842152d62213634dd7e7',1,'graphics.h']]],
  ['helvetica_2',['HELVETICA',['../class_p_d_f.html#ab6166de03f6346e5c18b38136948e96daadbb6e7594ac5ea7f5eb0abbac07375d',1,'PDF']]],
  ['helvetica_5fbold_3',['HELVETICA_BOLD',['../class_p_d_f.html#ab6166de03f6346e5c18b38136948e96da9b17129f6d3a47733aae56aaecda9a70',1,'PDF']]],
  ['helvetica_5fbold_5foblique_4',['HELVETICA_BOLD_OBLIQUE',['../class_p_d_f.html#ab6166de03f6346e5c18b38136948e96daf3850843a1a06305282f37b6c5716974',1,'PDF']]],
  ['helvetica_5foblique_5',['HELVETICA_OBLIQUE',['../class_p_d_f.html#ab6166de03f6346e5c18b38136948e96da600ca8ff63bdcffd09ed19c201961fcf',1,'PDF']]],
  ['hercmono_6',['HERCMONO',['../graphics_8h.html#a7a6cc9f3cbe0d0df1d1e9bc4fa61f292a562fc14716e6117c970a000d074e4f12',1,'graphics.h']]],
  ['hercmonohi_7',['HERCMONOHI',['../graphics_8h.html#a494eafa9fb6122b82b9e539fa7b78039acafd20cf8337513f302d728d240d0089',1,'graphics.h']]],
  ['horiz_8',['horiz',['../structtextsettingstype.html#a28143d2c28ee47b783816020e13d3da5',1,'textsettingstype::horiz()'],['../graphics_8h.html#a92d4e48b203a72f10f2471d0906d7f43',1,'horiz():&#160;graphics.h']]],
  ['horiz_5fdir_9',['HORIZ_DIR',['../graphics_8h.html#a0d80851f654297f3cb02b7d56f9f7bf9',1,'graphics.h']]]
];
