var searchData=
[
  ['red_5fvalue_0',['RED_VALUE',['../graphics_8h.html#a20f2f9e7c5b225b259a7e97b5480847a',1,'graphics.h']]],
  ['rigth_1',['RIGTH',['../_options_8h.html#a68d3b4844af3c14895cc69ef48f2c077',1,'Options.h']]]
];
