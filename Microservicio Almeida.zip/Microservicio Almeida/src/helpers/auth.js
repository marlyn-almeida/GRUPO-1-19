export const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  req.flash("error_msg", "Not Authorized."); //seguridad (integridad de datos por el uso de sesiones)
  res.redirect("/users/signin");
};
