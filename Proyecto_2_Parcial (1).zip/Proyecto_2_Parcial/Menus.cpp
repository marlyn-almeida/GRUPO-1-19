	#include "Menus.h"


	SplayTree arbol;
	
	
	/**
	 * @brief Menu de opciones del programa utilizando el teclado para desplazarse
	 * @param opciones Arreglo de mensajes para mostrar en pantalla las opciones
	 * @param persona Arreglo de tipo Persona donde se encuentran los atributos
	 * @param num Numero de opciones
	 * @param cont Contador
	 */
	int Menus::menu(string opciones[], string orden, int num, int tam)
	{
	    int cursor = 0;
		char tecla;
		int opcion;
		system("cls");
		for (;;) {
			system("cls");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
			cout << orden << endl;
			
			for (int i = 0; i < num; i++){
				if (cursor == i){
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
					cout << "\t\t> " <<opciones[i] << endl;
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	
				}
				else{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
					cout << "\t\t" <<opciones[i] << endl;
				}
			}
			for (;;){
				//arbol.prettyPrint();
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
				cout << "\t\t==============================\n\n" << endl;
				arbol.printBST();
				tecla = _getch();
				if (tecla == 80){
					cursor++;
					if (cursor == num){
						cursor = 0;
					}
					break;
				}
				if (tecla == 72){
					cursor--;
					if (cursor == -1){
						cursor = num-1;
					}
					break;
				}
				if (tecla == 13){
				    return cursor;
				}
			}
		}
	
	}
	
	
	/**
	 * @brief Menu para seleccion de opciones
	 * @param opciones Arreglo de mensajes para mostrar en pantalla las opciones
	 * @param persona Arreglo de tipo Persona donde se encuentran los atributos
	 * @param num Numero de opciones
	 * @param cont Contador
	 */
	void Menus::menuTeclas(string opciones[], int num, int tam  )
	{

		//Tipo de dato que ingresa, tipo de dato que sale
		typedef int (WINAPI *Validar_int_NP)(char*);
		Validar_int_NP validar_int_NP;
		HINSTANCE libDLL=NULL;// inicializamos la libreria con Null
		libDLL = LoadLibrary ("Proyecto 1.dll"); //Cargamos la libreria
		validar_int_NP=(Validar_int_NP)GetProcAddress(libDLL,"ingresarDatos_Int_N_P");
		int date;
		Generar pdf;
		Imagen imagen;
		Backup backup;
	
		string orden = "\n\t\t=========SPLAY TREE==========\n";
	   	int cursor = menu(opciones, orden, num, tam);
	    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	    switch (cursor){
	    case 0: { //Ingresar 
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\tInsertar valor en el arbol\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        
	        date=validar_int_NP("\nIngrese Valor ->");
	        arbol.insert(date);
	        save_files(date,"Datos.txt");
	        
	        //system("pause");
	        menuTeclas(opciones, num, tam);
	        
	    } break;
	    case 1: {//Buscar  
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\tBuscar valor en el arbol\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	      
	        date=validar_int_NP("\nIngrese Valor a Buscar ->");
	 		(arbol.searchTree(date) == nullptr)?  cout << "\nNo existe valor \n" : cout << "\nDato Encontrado ->"<<date << "\n";
        	save_files(date,"Busqueda.txt");
	   
	     	system("pause");
	        menuTeclas(opciones, num, tam);
	        break;
	    }
	    case 2: {//Eliminar
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\tEliminar valor en el arbol\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        
	        //TODO
	        date=validar_int_NP("\nIngrese Valor a Eliminar ->");
	        arbol.deleteNode(date);
	        save_files(date,"Eliminados.txt");
	        
			system("pause");
	        menuTeclas(opciones, num, tam);
	        
		}
	    case 3: {//foto 
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\tImprimir Foto\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        
	        imagen.Imagenes();
	        
			//system("pause");
	    	menuTeclas(opciones, num, tam);
	        break;
		}
		case 4: {//pdf
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\tGenerar Reporte (PDF,TXT)\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        
	        
	   		pdf.generarPDF("Datos.pdf");
			system("Datos.pdf");
			system("Datos.txt");
			        
	        //system("pause");
			menuTeclas(opciones, num, tam);
	        break;
		}
		case 5: {//BACKUP
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\tBACKUP\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        
	 		//TODO
	 		backup.generarBackup();
	 		system("start Backups\\");
			        
	        system("pause");
			menuTeclas(opciones, num, tam);
	        break;
		}
		case 6: {//Ayuda
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\tAYUDA AL USUARIO\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        
	 		//TODO
	 		system("FullObjectReport.html");
	 		
	        system("pause");
			menuTeclas(opciones, num, tam);
	        break;
		}
	    case 7: {//Salir
	        system("cls");
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
	        cout<<"\n\t\t...Gracias por usar mi programa...\n"<<endl;
	        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
	        system("pause");
	        exit(1);
	        break;
	
	    }
	}
}

void Menus::save_files(int date,string name)
{
    fstream archivo;
    fstream usuarios;
    FILE nuevo;
    check_files(name);
    archivo.open(name, ios::app);
    if (archivo.fail() || usuarios.fail()) {
        cout << "Ha ocurrido un error al verificar el archivo" << endl;
        exit(1);
    }
    else {
        archivo << "=======DATO INGRESADO EN EL ARBOL=======\n"<<
		"Dato: " << date <<endl;
    }
}


void Menus::check_files(string name)
{
    fstream archivo;
    fstream usuarios;
    archivo.open(name, ios::app);
    if (archivo.fail()) {
        cout << "Error al verificar Banco.txt" << endl;
        system("pause");
        create_files(name);
        system("cls");
        check_files(name);
    }
    else {
       
    }
    archivo.close();
    usuarios.close();
}

void Menus::create_files(string name)
{
    fstream archivo;
    fstream usuarios;
    string ruta = name;
    archivo.open(ruta.c_str(), ios::out);
    if (archivo.fail() || usuarios.fail()) {
        cout << "Ha ocurrido un error creando el archivo" << endl;
        system("cls");
        exit(1);
    }
    archivo.close();
    usuarios.close();

}