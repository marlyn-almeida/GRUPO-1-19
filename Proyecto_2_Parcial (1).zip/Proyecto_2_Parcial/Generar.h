class Generar
{
public:
    Generar();
    ~Generar();
    void generarPDF(string);
};
