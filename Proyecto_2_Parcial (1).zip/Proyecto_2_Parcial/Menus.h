#pragma once
#include <iostream>
#include <conio.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <Windows.h>
#include <time.h>
#include "arbol.h"
#include "Generar.h"
#include "Imagen.h" 
#include "Backup.h"

using namespace std;

class Menus{
	private:
    	
	public:
 	    int menu(string [], string, int, int);
  	    void menuTeclas(string [], int, int);
  	    void save_files(int,string);
		void check_files(string);
		void create_files(string);
};

