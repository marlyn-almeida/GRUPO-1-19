#include "Backup.h"

Backup::Backup()
{
}

Backup::~Backup()
{
}

void Backup::generarBackup(){
    time_t t;
    t=time(NULL);
    struct tm *f;
    f=localtime(&t);

    int dia,mes,anio,hora,min;
    dia=f->tm_mday;
    mes=f->tm_mon+1;
    anio=f->tm_year+1900;
    hora=f->tm_hour;
    min=f->tm_min;

    std::string linea;
    std::string texto,texto1,texto2;
    std::string fecha;
	std::string direccion;
    std::string anio1=(std::to_string(anio));
    std::string mes1=(std::to_string(mes));
    std::string dia1=(std::to_string(dia));
    std::string hora1=(std::to_string(hora));
    std::string min1=(std::to_string(min));
    fecha = "Backups\\"+dia1+"-"+mes1+"-"+anio1+"-"+hora1+"h"+min1+"m"+"_BackupEliminados"+".txt";
	std::ifstream original("Eliminados.txt");
    while (getline(original,linea))
    {
        texto=texto+linea+"\n";
    }
    original.close();
    std::ofstream backup;
    backup.open(fecha);
    backup<<texto;
    backup.close();
    
    fecha = "Backups\\"+dia1+"-"+mes1+"-"+anio1+"-"+hora1+"h"+min1+"m"+"_BackupBusqueda"+".txt";
    std::ifstream original1("Busqueda.txt");
    while (getline(original1,linea))
    {
        texto1=texto1+linea+"\n";
    }
    original1.close();
    std::ofstream backup1;
    backup1.open(fecha);
    backup1<<texto1;
    backup1.close();
  
}