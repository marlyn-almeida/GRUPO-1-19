#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <complex>
#include <cmath>
#include "pdf.h"
#include "metrics.h"
#include "Generar.h"

using std::complex;
using std::cout;
using std::endl;
using std::ifstream;
using std::ios;
using std::ostringstream;

Generar::Generar()
{
}

Generar::~Generar()
{
}

void Generar::generarPDF(string nombre)
{
    int n=50;
    PDF p;
    p.setFont(PDF::HELVETICA, 12);
    
    string linea, texto;
    int y=50;
    ifstream original("Datos.txt");
    while (getline(original, linea))
    {
    	
        p.showTextXY(linea, y, n);
        n=n+10;
    }
    p.showTextXY("--NUMEROS INGRESADOS--",n+10,10);
    original.close();
	string errMsg;

    if (!p.writeToFile(nombre, errMsg))
    {
        cout << errMsg << endl;
    }
    else
    {
        cout << "(File Successfully Written)" << endl;
    }

    cout << endl;
}