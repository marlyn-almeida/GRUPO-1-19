#include <iostream>
#include "gotoxy.h"
//#include "gotoxy.cpp"
#define LEFT 0
#define RIGHT 1
#define MARGIN_LEFT 5
#define DIST_NODE 2

using namespace std;

// data structure that represents a node in the tree
class Node {
public:
    int data; // holds the key
    Node *parent; // pointer to the parent
    Node *left; // pointer to left child
    Node *right; // pointer to right child
};

typedef Node *NodePtr;

// class SplayTree implements the operations in Splay tree
class SplayTree {
private:
    NodePtr root;


    void preOrderHelper(NodePtr node) {
        if (node != nullptr) {
            cout<<node->data<<" ";
            preOrderHelper(node->left);
            preOrderHelper(node->right);
        }
    }

    void inOrderHelper(NodePtr node) {
        if (node != nullptr) {
            inOrderHelper(node->left);
            cout<<node->data<<" ";
            inOrderHelper(node->right);
        }
    }

    void postOrderHelper(NodePtr node) {
        if (node != nullptr) {
            postOrderHelper(node->left);
            postOrderHelper(node->right);
            cout<<node->data<<" ";
        }
    }


    void deleteNodeHelper(NodePtr node, int key) {
        NodePtr x = nullptr;
        NodePtr t, s;
        while (node != nullptr){
            if (node->data == key) {
                x = node;
            }

            if (node->data <= key) {
                node = node->right;
            } else {
                node = node->left;
            }
        }

        if (x == nullptr) {
            cout<<"No se pudo encontrar el dato en el árbol."<<endl;
            return;
        }
        split(x, s, t); // split the tree
        if (s->left){ // remove x
            s->left->parent = nullptr;
        }
        root = join(s->left, t);
        delete(s);
        s = nullptr;
    }



    // rotate left at node x
    void leftRotate(NodePtr x) {
        NodePtr y = x->right;
        x->right = y->left;
        if (y->left != nullptr) {
            y->left->parent = x;
        }
        y->parent = x->parent;
        if (x->parent == nullptr) {
            this->root = y;
        } else if (x == x->parent->left) {
            x->parent->left = y;
        } else {
            x->parent->right = y;
        }
        y->left = x;
        x->parent = y;
    }

    // rotate right at node x
    void rightRotate(NodePtr x) {
        NodePtr y = x->left;
        x->left = y->right;
        if (y->right != nullptr) {
            y->right->parent = x;
        }
        y->parent = x->parent;
        if (x->parent == nullptr) {
            this->root = y;
        } else if (x == x->parent->right) {
            x->parent->right = y;
        } else {
            x->parent->left = y;
        }
        y->right = x;
        x->parent = y;
    }


    ///Section Add
    int menoresQue(NodePtr node, int d){
        if(node){
            int izq = menoresQue(node->left, d);
            int der = menoresQue(node->right, d);
            if(node->data < d) return 1 + izq + der;
            else return izq + der;
        }
        else return 0;
    }



    void printBT(NodePtr r, NodePtr padre, int dir, int posX, int posY){
        if(r){

            int posX2 = menoresQue(padre, r->data) * DIST_NODE + MARGIN_LEFT;
            printBT(r->left, padre, LEFT, posX2, posY + 2);
            gotoxy(posX2, posY);

            printf("%d ", r->data);

            if(dir == LEFT){
                gotoxy(posX2, posY-1);
                printf("_/");
                for(int i = posX2 + 2; i < posX; i++){
                    gotoxy(i, posY-1);
                    printf("%c", 238);
                }
            }else if(dir == RIGHT){
                gotoxy(posX +2, posY-1);
                for(int i = posX +2; i < posX2; i++){
                    gotoxy(i, posY-1);
                    printf("%c", 238);
                }
                printf("%c_", 92);
            }
            printBT(r->right, padre, RIGHT, posX2, posY + 2);
        }
    }

    /////////////////////





    // splaying
    void splay(NodePtr x) {
        while (x->parent) {
            if (!x->parent->parent) {
                if (x == x->parent->left) {
                    // zig rotation
                    rightRotate(x->parent);
                } else {
                    // zag rotation
                    leftRotate(x->parent);
                }
            } else if (x == x->parent->left && x->parent == x->parent->parent->left) {
                // zig-zig rotation
                rightRotate(x->parent->parent);
                rightRotate(x->parent);
            } else if (x == x->parent->right && x->parent == x->parent->parent->right) {
                // zag-zag rotation
                leftRotate(x->parent->parent);
                leftRotate(x->parent);
            } else if (x == x->parent->right && x->parent == x->parent->parent->left) {
                // zig-zag rotation
                leftRotate(x->parent);
                rightRotate(x->parent);
            } else {
                // zag-zig rotation
                rightRotate(x->parent);
                leftRotate(x->parent);
            }
        }
    }

    // joins two trees s and t
    NodePtr join(NodePtr s, NodePtr t){
        if (!s) {
            return t;
        }

        if (!t) {
            return s;
        }
        NodePtr x = maximum(s);
        splay(x);
        x->right = t;
        t->parent = x;
        return x;
    }

    // splits the tree into s and t
    void split(NodePtr &x, NodePtr &s, NodePtr &t) {
        splay(x);
        if (x->right) {
            t = x->right;
            t->parent = nullptr;
        } else {
            t = nullptr;
        }
        s = x;
        s->right = nullptr;
        x = nullptr;
    }



public:
    SplayTree() {
        root = nullptr;
    }

    void printBST() {
        int posY = whereY();
        int posX = 0;
        printBT(root, root, -1, posX, posY);
        gotoxy(0, posY + altura(root)  * 2);
    }


    // Pre-Order traversal
    // Node->Left Subtree->Right Subtree
    void preorder() {
        preOrderHelper(this->root);
    }

    // In-Order traversal
    // Left Subtree -> Node -> Right Subtree
    void inorder() {
        inOrderHelper(this->root);
    }

    // Post-Order traversal
    // Left Subtree -> Right Subtree -> Node
    void postorder() {
        postOrderHelper(this->root);
    }

    // search the tree for the key
    // and return the corresponding node
    NodePtr searchTree(int key) {
        auto temp = this->root;
        while (temp){
            if (temp->data == key) {splay(temp);return temp; }
            else if (temp->data < key ) temp = temp->right;
            else temp = temp->left;
        }
        return nullptr;
    }

    // find the node with the minimum key
    NodePtr minimum(NodePtr node) {
        while (node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    // find the node with the maximum key
    NodePtr maximum(NodePtr node) {
        while (node->right != nullptr) {
            node = node->right;
        }
        return node;
    }

    // find the successor of a given node
    NodePtr successor(NodePtr x) {
        // if the right subtree is not null,
        // the successor is the leftmost node in the
        // right subtree
        if (x->right != nullptr) {
            return minimum(x->right);
        }

        // else it is the lowest ancestor of x whose
        // left child is also an ancestor of x.
        NodePtr y = x->parent;
        while (y != nullptr && x == y->right) {
            x = y;
            y = y->parent;
        }
        return y;
    }

    // find the predecessor of a given node
    NodePtr predecessor(NodePtr x) {
        // if the left subtree is not null,
        // the predecessor is the rightmost node in the
        // left subtree
        if (x->left != nullptr) {
            return maximum(x->left);
        }

        NodePtr y = x->parent;
        while (y != nullptr && x == y->left) {
            x = y;
            y = y->parent;
        }

        return y;
    }


    int altura(NodePtr node)
    {
        return (node == nullptr)? 1:
               1 + std::max(altura(node->left), altura(node->right));
    }

    int altura(){
        return altura(root);
    }

    // insert the key to the tree in its appropriate position
    void insert(int key) {
        // normal BST insert
        NodePtr node = new Node;
        node->parent = nullptr;
        node->left = nullptr;
        node->right = nullptr;
        node->data = key;
        NodePtr y = nullptr;
        NodePtr x = this->root;
        while (x != nullptr) {
            y = x;
            if (node->data < x->data) {
                x = x->left;
            } else {
                x = x->right;
            }
        }

        // y is parent of x
        node->parent = y;
        if (y == nullptr) {
            root = node;
        } else if (node->data < y->data) {
            y->left = node;
        } else {
            y->right = node;
        }

        // splay at insert node
        splay(node);
    }

    // deletes the node from the tree with given key
    void deleteNode(int key) {
        deleteNodeHelper(this->root, key);
    }
};
